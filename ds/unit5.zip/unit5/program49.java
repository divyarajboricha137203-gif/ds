import java.sql.*;
import java.util.Scanner;

public class PreparedDisplay {
    public static void main(String[] args) {
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        String user = "system";
        String password = "password";

        Scanner sc = new Scanner(System.in);

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection(url, user, password);

            String sql = "SELECT roll_no, name, marks FROM student WHERE marks >= ?";
            PreparedStatement pstmt = con.prepareStatement(sql);

            System.out.print("Enter minimum marks to filter: ");
            double minMarks = sc.nextDouble();

            // Set parameter
            pstmt.setDouble(1, minMarks);

            ResultSet rs = pstmt.executeQuery();

            System.out.println("\nRoll No\tName\tMarks");
            System.out.println("-----------------------");
            boolean found = false;
            while (rs.next()) {
                found = true;
                System.out.println(rs.getInt("roll_no") + "\t" +
                                   rs.getString("name") + "\t" +
                                   rs.getDouble("marks"));
            }

            if (!found) {
                System.out.println("No matching records found.");
            }

            rs.close();
            pstmt.close();
            con.close();
            sc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
