import java.sql.*;

public class DeleteRecord {
    public static void main(String[] args) {
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        String user = "system";
        String password = "password";

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection(url, user, password);
            Statement stmt = con.createStatement();

            String sql = "DELETE FROM student WHERE roll_no = 101";
            int rows = stmt.executeUpdate(sql);

            System.out.println(rows + " record(s) deleted successfully.");

            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
