import java.sql.*;
import java.util.Scanner;

public class PreparedUpdateDelete {
    public static void main(String[] args) {
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        String user = "system";
        String password = "password";

        Scanner sc = new Scanner(System.in);

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection(url, user, password);

            System.out.println("Choose an operation:");
            System.out.println("1. Update Student Marks");
            System.out.println("2. Delete Student Record");
            System.out.print("Enter choice (1 or 2): ");
            int choice = sc.nextInt();

            if (choice == 1) {
                // UPDATE Operation
                String updateSql = "UPDATE student SET marks = ? WHERE roll_no = ?";
                PreparedStatement pstmt = con.prepareStatement(updateSql);

                System.out.print("Enter Roll Number to update: ");
                int roll = sc.nextInt();

                System.out.print("Enter New Marks: ");
                double newMarks = sc.nextDouble();

                pstmt.setDouble(1, newMarks);
                pstmt.setInt(2, roll);

                int rows = pstmt.executeUpdate();
                System.out.println(rows + " record(s) updated successfully.");
                pstmt.close();

            } else if (choice == 2) {
                // DELETE Operation
                String deleteSql = "DELETE FROM student WHERE roll_no = ?";
                PreparedStatement pstmt = con.prepareStatement(deleteSql);

                System.out.print("Enter Roll Number to delete: ");
                int roll = sc.nextInt();

                pstmt.setInt(1, roll);

                int rows = pstmt.executeUpdate();
                System.out.println(rows + " record(s) deleted successfully.");
                pstmt.close();

            } else {
                System.out.println("Invalid choice.");
            }

            con.close();
            sc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
