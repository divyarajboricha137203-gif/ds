import java.sql.*;
import java.util.Scanner;

public class PreparedInsert {
    public static void main(String[] args) {
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        String user = "system";
        String password = "password";

        Scanner sc = new Scanner(System.in);

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection(url, user, password);

            String sql = "INSERT INTO student (roll_no, name, marks) VALUES (?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(sql);

            System.out.print("Enter Roll Number: ");
            int roll = sc.nextInt();
            sc.nextLine(); // Consume newline

            System.out.print("Enter Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Marks: ");
            double marks = sc.nextDouble();

            // Bind values to placeholders
            pstmt.setInt(1, roll);
            pstmt.setString(2, name);
            pstmt.setDouble(3, marks);

            int rows = pstmt.executeUpdate();
            System.out.println(rows + " record(s) inserted successfully.");

            pstmt.close();
            con.close();
            sc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
