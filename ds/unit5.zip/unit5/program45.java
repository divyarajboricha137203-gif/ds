import java.sql.*;

public class DisplayRecords {
    public static void main(String[] args) {
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        String user = "system";
        String password = "password";

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection(url, user, password);
            Statement stmt = con.createStatement();

            String sql = "SELECT * FROM student";
            ResultSet rs = stmt.executeQuery(sql);

            System.out.println("Roll No\tName\tMarks");
            System.out.println("-----------------------");
            while (rs.next()) {
                System.out.println(rs.getInt("roll_no") + "\t" + 
                                   rs.getString("name") + "\t" + 
                                   rs.getDouble("marks"));
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
